const express = require('express');
const router = express.Router();

const userController = require('../controllers/userController');

router.get('/login',userController.test);
router.post('/create',userController.user_create);
router.post('/getUser',userController.user_read);

module.exports = router;