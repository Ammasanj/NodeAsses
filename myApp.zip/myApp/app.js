// Aum Amma

const express = require('express')
const bodyParser = require('body-parser');

const app = express();
const router = require('./routes/userRouter');

const mongoose = require('mongoose');

app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

//Mongoose connectivity


let deb_url = "mongodb://127.0.0.1:27017/userInfo";

let mongoDB = deb_url;
mongoose.connect(mongoDB,{ useNewUrlParser: true });
mongoose.Promise = global.Promise;
let db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));


app.get('/', function (req, res) {
	res.render('signUp.ejs');
})

app.use('/user', router);




app.listen(3000, () => {

	console.log("server is listening");
})