const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let UserSchema = new Schema({
  userName:{type:"string",required:true,max:50},
  password:{type:"string",required:true},
  email:{type:"string",required:true},
  firstName:{type:"string",required:true,max:50},
  lastName:{type:"string",required:true,max:50},
  country:{type:"string",required:true},
  gender:{type:"string",required:true}
});

module.exports = mongoose.model('user',UserSchema,'user');