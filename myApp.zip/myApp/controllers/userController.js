const User = require('../models/userModel');

//Simple version, without validation or sanitation
exports.test = function (req, res) {
    res.render('login');
};

// USER _ Registration(add to the database)
exports.user_create = function (req, res,next) {

    console.log(req.body,"req.body")

    let userInfo = new User(
        {
            userName:req.body.userName,
            password:req.body.password,
            email:req.body.email,
            firstName:req.body.firstName,
            lastName:req.body.lastName,
            country:req.body.country,
            gender:req.body.gender
        }
    );

    userInfo.save(function (err) {
        if (err) {
            console.log(err,"oops error occured")
            //return next(err);
        }
        res.render('login')
    })
};
// login: authentication
exports.user_read = function(req,res,next){
    
let query = {
    name :req.body.userName,
    password:req.body.password
}
User.find({userName:query.name},(err,user)=>{
    
    if(err){
        return
    }

if(user ===user.length<0){
    res.render("login");
}else if(user[0].userName === query.name && user[0].password === query.password){
    res.render('welcome',query);
}else{

    res.render("login");

}


})

}