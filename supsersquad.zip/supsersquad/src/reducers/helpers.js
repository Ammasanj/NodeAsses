import data from '../data/characters.json';

function findCharector (id){
    let hero = data.find(c => c.id === id);
    return hero;
    
}

export default findCharector;

