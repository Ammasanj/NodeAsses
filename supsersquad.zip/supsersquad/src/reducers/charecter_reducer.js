import data from '../data/characters.json';
import { ADD_CHARECTER,REMOVE_CHARACTER } from "../actions";
import findCharector from '../reducers/helpers';



function characters(state = data,action){
    switch(action.type){
        case ADD_CHARECTER:
        let character = state.filter(item =>item.id !==action.id);
        return character;
        case REMOVE_CHARACTER: 
        let heroes = [...state,findCharector(action.id)];
        return heroes;
        default: 
            return state;
    }

}

export default characters;