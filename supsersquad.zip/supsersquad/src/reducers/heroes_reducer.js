
import { ADD_CHARECTER,REMOVE_CHARACTER } from "../actions";
import findCharector from './helpers'

function heroes(state =[],action){
    switch(action.type){
        case ADD_CHARECTER:
                let character = [...state,findCharector(action.id)];
                 return character;
        case REMOVE_CHARACTER:
                let herolist = state.filter(item=>item.id !==action.id);
                return herolist;
        default: 
            return state;
    }
}

export default heroes;