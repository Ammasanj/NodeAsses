export const ADD_CHARECTER ="ADD_CHARECTOR";

export const REMOVE_CHARACTER ="REMOVE_CHARECTOR" ;


export function addCharecter(id){
    const action ={
        type: ADD_CHARECTER,
        id
    }
    return action;

}

export function removeCharecter(id){
    const action = {
        type:REMOVE_CHARACTER,
        id
    }
    return action;
}