
import React, {Component} from 'react';
import { connect } from 'react-redux';
import {removeCharecter} from '../actions';
class HeroList extends Component{

    render(){

        return (<div className="App">
        <div><h3>My Heroes</h3></div>
            <ul className="list-group">
                {
                    this.props.hero.map(item =>{

                        return <li className="list-group-item" key={item.id +item.name}>{item.name}
                            <div className = "list-item right-button" onClick = {() =>this.props.removeCharecter(item.id)}>X </div>
                        </li>
                    })
                }


            </ul>
        </div>)
    }

   


}
function mapStateToProps(state){
 
   return {hero:state.heroes};
       
}

export default connect(mapStateToProps,{removeCharecter})(HeroList);