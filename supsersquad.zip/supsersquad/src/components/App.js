import React,{Component} from 'react';
import CharacterList from './characterList';
import HeroList from './HeroList';
import SquadStats from './SquadStats'
import '../style/index.css'


class App extends Component{
    render(){
        return(
            <div className="App row">
            <div className="col-md-3">
            <CharacterList />  
            </div>
            <div className ="col-md-3">
            <HeroList />
            </div>
            <div className ="col-md-3">
            <SquadStats />
            </div>   
               
            </div>
            
        )
    }
}

export default App;