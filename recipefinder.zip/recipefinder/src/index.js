import React from 'react';
import ReactDOM from 'react-dom';
import{BrowserRouter,Switch,Route} from 'react-router-dom';
import App from './component/App';

import {createStore} from 'redux';
import {Provider} from 'react-redux';
import Reducer from './reducer';
import FavoriteRecipeList from './component/FavoriteRecipeList';

const store = createStore(Reducer);
store.subscribe(()=>console.log('store',store.getState()));



ReactDOM.render(
<Provider store = {store}>
<BrowserRouter>
<Switch>
    <Route exact path = '/' component = {App}></Route>
    <Route path = '/favorites' component ={FavoriteRecipeList}></Route>
</Switch>
</BrowserRouter>

 </Provider>,document.getElementById('root'));