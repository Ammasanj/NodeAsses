import React, {Component} from 'react';
import {Form,FormGroup,FormControl,Button} from 'react-bootstrap';
import '../styles/index.css';

import {connect} from 'react-redux';
import {setRecipe} from '../action';
import data from '../data/data.json'

class SerchRecipe extends Component{
    constructor(props){
        super(props);
        this.state = {
            ingredients:'',
            dish:''
        }
    }
    search(){
       // let {ingredients,dish} = this.state;
       // const url = `http://www.recipepuppy.com/api/?i=${ingredients} &q=${dish}`;
        this.props.setRecipe(data)
        // fetch(url,{
        //     method:'GET'
        // })
        // .then(res =>res.json)
        // .then(json =>{
        //     //console.log(json.results)
        //     this.props.setRecipe(data)
        // })
        // .catch(err =>{
        //     console.log(err)
        // });
        
        // console.log(url)
    }
    render(){
        return (
            <Form inline>
                <FormGroup>
                    <span >Ingredients</span>
                    {' '}
                    <FormControl type="text" placeholder = "Garlic,Chicken" onChange ={event => this.setState({ingredients:event.target.value}) }></FormControl>

                </FormGroup>
                {' '}
                <FormGroup>
                    <span>Dish</span>
                    { ' '}
                    <FormControl type ="text" placeholder = "Adobo" onChange = {event =>this.setState({dish:event.target.value})}></FormControl>
                </FormGroup>
                {' '}
                <Button onClick = {() => this.search()}>Submit</Button>
            </Form>
        )
    }

}

export default connect(null,{setRecipe})(SerchRecipe);

