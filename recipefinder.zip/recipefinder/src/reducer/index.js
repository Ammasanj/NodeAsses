import {combineReducers} from 'redux'
import {SET_RECIPE,FAVORITE_RECIPE} from '../action';

function recipe(state = [],action){
    switch(action.type){
        case SET_RECIPE: 
                return action.item;
        default:
            return state;
    }

}

function favoriteRecipe(state = [],action){
    switch(action.type){
        case FAVORITE_RECIPE:
                state = [...state,action.recipe];
                return state;
         default:
                 return state;
    }
}

const Reducer = combineReducers({recipe,favoriteRecipe});

export default Reducer;