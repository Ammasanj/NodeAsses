export const SET_RECIPE = "SET_RECIPE";
export const FAVORITE_RECIPE = "FAVORITE_RECIPE";

export function setRecipe(item){
    return {
        type:SET_RECIPE,
        item
    }
}

export function favoriteRecipe(recipe){
    return {
        type:FAVORITE_RECIPE,
        recipe
    }
}